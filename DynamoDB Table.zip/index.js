const express = require("express");
const http = require("http");
const path = require("path");
const { WebSocketServer } = require("ws");
// NEW: Import the DynamoDB client from the AWS SDK
const {
  DynamoDBClient,
  ScanCommand,
  PutItemCommand,
  GetItemCommand,
} = require("@aws-sdk/client-dynamodb");

// --- AWS and App Setup ---
const port = process.env.PORT || 3000;
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// NEW: Initialize the DynamoDB client
const dynamoDBClient = new DynamoDBClient({
  region: process.env.AWS_REGION || "eu-north-1",
});
const tableName = "Trading_Signals";

// --- State Management for the Grid ---
let signalState = {};
let symbolOrder = [];

// --- Middleware ---
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// --- Helper Functions ---
function broadcastState() {
  const payload = JSON.stringify({
    state: signalState,
    symbolOrder: symbolOrder,
  });
  for (const client of wss.clients) {
    if (client.readyState === client.OPEN) {
      client.send(payload);
    }
  }
}

// --- WebSocket Connection Handling ---
wss.on("connection", (ws) => {
  console.log("🔗 Client connected");
  ws.isAlive = true;

  ws.on("pong", () => {
    ws.isAlive = true;
  });

  // Send the current state and order when a new client connects
  ws.send(
    JSON.stringify({
      state: signalState,
      symbolOrder: symbolOrder,
    })
  );
  ws.on("close", () => console.log("👋 Client disconnected"));
});

// --- Heartbeat Interval ---
const interval = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (ws.isAlive === false) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

// --- API Endpoints ---
app.post("/webhook", async (req, res) => {
  // NEW: Changed to an async function
  const { symbol, term, signal, indicator, price, time } = req.body;

  if (!symbol || !term || !signal || !indicator || !price || !time) {
    return res.status(400).send("Invalid webhook data. Missing fields.");
  }

  if (!signalState[symbol]) {
    signalState[symbol] = {
      long_buy_1: null,
      long_sell_1: null,
      short_buy_2: null,
      short_buy_3: null,
      short_sell_2: null,
      short_sell_3: null,
    };
    console.log(`✨ New symbol added to state: ${symbol}`);
  }

  const existingIndex = symbolOrder.indexOf(symbol);
  if (existingIndex > -1) {
    symbolOrder.splice(existingIndex, 1);
  }
  symbolOrder.unshift(symbol);

  const stateKey = `${term}_${signal}_${indicator}`;

  if (signalState[symbol].hasOwnProperty(stateKey)) {
    signalState[symbol][stateKey] = { price, time, newSince: Date.now() };
    console.log(`✅ State updated for ${symbol}: ${stateKey} -> ${price}`);
  } else {
    console.warn(
      `⚠️ Received signal for an invalid or obsolete key: ${stateKey}. Signal ignored.`
    );
  }

  // --- NEW: Persist the updated state to DynamoDB ---
  try {
    // Calculate the expiration time (15 days from now) in Unix epoch seconds
    const ttl_timestamp = Math.floor(Date.now() / 1000) + 15 * 24 * 60 * 60;

    const params = {
      TableName: tableName,
      Item: {
        symbol: { S: symbol },
        stateData: { S: JSON.stringify(signalState[symbol]) },
        lastUpdated: { S: new Date().toISOString() },
        ttl: { N: ttl_timestamp.toString() }, // The TTL attribute we configured
      },
    };
    await dynamoDBClient.send(new PutItemCommand(params));
    console.log(`💾 Persisted state for ${symbol} to DynamoDB.`);
  } catch (dbError) {
    console.error("🔥 DynamoDB Put Error:", dbError);
  }
  // --- End of new code ---

  broadcastState();
  res.status(200).send("Webhook received!");
});

// --- NEW: Function to load data from DynamoDB on startup ---
async function loadDataFromDB() {
  console.log("...Loading initial data from DynamoDB...");
  try {
    const params = { TableName: tableName };
    const data = await dynamoDBClient.send(new ScanCommand(params));

    if (data.Items) {
      // Sort items by lastUpdated to maintain order
      data.Items.sort(
        (a, b) => new Date(b.lastUpdated.S) - new Date(a.lastUpdated.S)
      );

      data.Items.forEach((item) => {
        const symbol = item.symbol.S;
        const stateData = JSON.parse(item.stateData.S);
        signalState[symbol] = stateData;
        symbolOrder.push(symbol);
      });
      console.log(
        `✅ Successfully loaded ${data.Items.length} symbols from DynamoDB.`
      );
    }
  } catch (dbError) {
    console.error("🔥 DynamoDB Scan Error on startup:", dbError);
  }
}

// --- Start Server ---
server.listen(port, async () => {
  // NEW: Changed to an async function
  await loadDataFromDB(); // Load data before starting to listen for connections
  console.log(`🚀 Server running on port ${port}`);
});
